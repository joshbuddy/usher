class Foo < ActiveRecord::Migration
  def self.up
  end

  def self.down
  end
end