class Person < ActiveResource::Base
  self.site = "http://37s.sunrise.i:3000"
end
